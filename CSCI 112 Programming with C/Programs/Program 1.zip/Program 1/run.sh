echo
./program1 17 < inp17.txt
cat output.txt
echo
./program1 2000 < inp2000.txt
cat output.txt
echo
./program1 5000 < inp5000.txt
cat output.txt
echo
./program1 8000 < inp8000.txt
cat output.txt
