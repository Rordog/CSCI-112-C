typedef struct {

    char className[40];
    char classNum[10];
    char lastName[12];
    char firstName[20];
    char seatNum[4];
    char days[4];
    char times[10];

} Class;
