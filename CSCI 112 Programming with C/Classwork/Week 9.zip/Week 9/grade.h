typedef struct {
    
    char name[50];
    char letterGrade[3];
    double gradeNum;

} Grade;
